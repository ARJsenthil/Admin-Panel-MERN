import { useState } from "react";
import { Link } from "react-router-dom";
// import Validation from "./Validation";
import axios from "axios";

function Valid()
{


    const [uname, setUname] = useState('');
    const [pass, setPass] = useState('');
    const [email, setEmail] = useState('');
    const [phno, setPhno] = useState('');
    const [unameerror, setUnameError] = useState(false);
    const [passerror, setPassError] = useState(false);
    const [emailerror, setEmailError] = useState(false);
    const [phnoerror, setPhnoError] = useState(false);
    const [passregexerror, setPassregexError] = useState(false);
    const [emailregexerror, setEmailregexError] = useState(false);
    const [phnoregexerror, setPhnoregexError] = useState(false);
    const [unameregexerror, setunameregexerror] = useState(false);
    const [unamereq, setUnameReq] = useState(true);


    const emailregex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const passregex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    const phnoregex = /(\+91[\s-]?)?[6-9]\d{9}\b/g;
    const unameregex = "^(?=.{8,20}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$";

    const inp = (event) =>{

        var tar = event.target
        var a = tar.value;
        if(tar.id == 'uname_id')
        {

            if(a.match(unameregex))
            {
                setunameregexerror(false);
            }
            else
            {
                setunameregexerror(true);
            }
            setUname(tar.value);
            setUnameError(false);
        
            let uname_id = document.getElementById('uname_id');
            if(uname_id.required == true)
            {
                setUnameReq(true)
                console.log('t');
                uname_id.required = false;
            }
            else if(uname_id.required == false)
            {
                console.log('f');
                setUnameReq(false)
            }

        }
        if(tar.id == 'pass_id')
        {
            if(a.match(passregex))
            {
                setPassregexError(false);
            }
            else
            {
                setPassregexError(true);
            }
            setPass(tar.value);
            setPassError(false);
        }
        if(tar.id == 'email_id')
        {
            if(a.match(emailregex))
            {
                

                setEmailregexError(false);
            }
            else
            {
                

                setEmailregexError(true);
            }
            setEmail(tar.value);
            setEmailError(false);
        }
        if(tar.id == 'phno_id')
        {
            if(a.length <= 10)
            {
            setPhno(tar.value);
            setPhnoError(false)};
            console.log(tar.value);
            if(a.match(phnoregex))
            {
                setPhnoregexError(false);
            }
            else
            {

                setPhnoregexError(true);
            }
        }
    }

    const submitBtn = () =>{

        {uname?setUnameError(false):setUnameError(true)}
        {pass?setPassError(false):setPassError(true)}
        {email?setEmailError(false):setEmailError(true)}
        {phno?setPhnoError(false):setPhnoError(true)}

        
        axios.post('https://dummyjson.com/products/add', {
            ufirstName: uname,
            uphno: phno,
            uemail : email,
            upass : pass
          })
          .then(function (response) {
            console.log(response);
          })
          .catch(function (error) {
            console.log(error);
          });
        
    
    
        
            if(unameerror == false && passerror == false   && emailerror == false && phnoerror == false && unameregexerror == false && passregexerror == false && emailregexerror == false && phnoregexerror == false && unamereq == false)
            {
                if(uname, pass, email, phno){
                alert('Mission Success');}
            }
    }

    const hide_show = () =>{
        let pass_type = document.getElementById('pass_id');
        if(pass_type.type === 'password')
        {
            pass_type.type = 'text';
        }
        else
        {
            pass_type.type = 'password';
        }

        
    }
    return (
        <form action="./test.php" className="p-5 bg-dark shadow-lg" style={{display:'grid', gap:'10px', justifyContent:'center', alignItems:'center', borderRadius:'30px', position:'absolute', top:'50%', left:'50%', transform:'translate(-50%, -50%)', background:'rgb(255, 255, 255, .3)'}}>
            <div>
                <h3 className="text-center">REGISTRATION</h3>
            </div>
            <div id="" className="uname" style={{width:'230px'}}>
                <input className="w-100" type="text" id="uname_id" value={uname} required placeholder="UserName" onChange={inp}/><br/>{unameerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>Required Field</label>:""}{unameregexerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>invalid username</label>:""}
            </div>
            <div id="" className="email" style={{width:'230px'}}>
                <input className="w-100" type="text" id="email_id" value={email} placeholder="Email" onChange={inp}/><br/>{emailerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>Required Field</label>:""}{emailregexerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>write a proper email(example@mail.com)</label>:""}
            </div>
            <div id="" className="pass" style={{position:'relative', width:'230px'}}>
            <input className="w-100" type="password" id="pass_id" value={pass} placeholder="Password" onChange={inp}/><button style={{background:'transparent', border:'none', position:'absolute', left:'203px', top:'6px'}} onClick={hide_show}>🧿</button><br/>{passerror?<label className="p-0 m-0 w-100" style={{color:'red',fontSize:'small'}}>Required Field</label>:""}{passregexerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small', textWrap:'wrap'}}>password minimum 8 char, one caps letter(A-Z), onespecial symbol, one number(eg - example!123)</label>:""}
            </div>
            <div id="" className="phno" style={{width:'230px'}}>
                <input className="w-100" type="number" id="phno_id" value={phno} maxLength={10} placeholder="Phone Number" onChange={inp}/><br/>{phnoerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>Required Field</label>:""}{phnoregexerror?<label className="p-0 m-0" style={{color:'red',fontSize:'small'}}>invalid phone number</label>:""}
            </div>
            <div id="" className="submit" style={{width:'230px'}}>
                <input className="w-100 px-2 py-1" type="submit" id="submit" value={'SUBMIT'} onClick={submitBtn}/>
            </div>
            <Link to='/home'>Next</Link>
        </form>
    );
}

export default Valid;