import { useEffect, useState } from "react";
import { ActionGetProductList } from "../actions/dashboard";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { Breadcrumb, Spinner, Table } from "react-bootstrap";
import swal from "sweetalert";
import axios from "axios";


function Product()
{
    const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(true)
    onLoad();
    }, []);

    const onLoad = async () => {
      try{
        await dispatch(ActionGetProductList());
      }
      catch(e){

      }
      finally{
      setLoading(false)
      }
    }
    const dashboardData = useSelector((state) => state);
    const productsList = dashboardData.dashboardReducer.productList;
    console.log(productsList)
    const delectProduct = (id, productName) =>
      {
        const data = {
            id : id
          }
        axios.post('http://localhost:3001/products/deleteProduct', data, { 
          headers : ""
         })
        .then(function (response) {
          swal('Deleted', 'Product '+productName+' Deleted Successfully', 'success');
          onLoad();
        })
        .catch(function (error) {
          swal('error', 'error', 'warning');
          console.log(error);
        });
      }
      if(loading)
        {
          return <Spinner animation="border" className="position-absolute" style={{ top : '50%', left : '50%', transform : 'translate(-50%. -50%)' }} variant="primary" />
        }
    return(
        
        <div className="container">
        <div className="py-3 clearfix">
            <h3 className="d-inline-block" style={{float : "left"}}>Product's List</h3>
            <Link to='/addproduct' className="text-decoration-none" style={{float : "right"}}>
            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-circle-dotted" viewBox="0 0 16 16">
            <path d="M8 0q-.264 0-.523.017l.064.998a7 7 0 0 1 .918 0l.064-.998A8 8 0 0 0 8 0M6.44.152q-.52.104-1.012.27l.321.948q.43-.147.884-.237L6.44.153zm4.132.271a8 8 0 0 0-1.011-.27l-.194.98q.453.09.884.237zm1.873.925a8 8 0 0 0-.906-.524l-.443.896q.413.205.793.459zM4.46.824q-.471.233-.905.524l.556.83a7 7 0 0 1 .793-.458zM2.725 1.985q-.394.346-.74.74l.752.66q.303-.345.648-.648zm11.29.74a8 8 0 0 0-.74-.74l-.66.752q.346.303.648.648zm1.161 1.735a8 8 0 0 0-.524-.905l-.83.556q.254.38.458.793l.896-.443zM1.348 3.555q-.292.433-.524.906l.896.443q.205-.413.459-.793zM.423 5.428a8 8 0 0 0-.27 1.011l.98.194q.09-.453.237-.884zM15.848 6.44a8 8 0 0 0-.27-1.012l-.948.321q.147.43.237.884zM.017 7.477a8 8 0 0 0 0 1.046l.998-.064a7 7 0 0 1 0-.918zM16 8a8 8 0 0 0-.017-.523l-.998.064a7 7 0 0 1 0 .918l.998.064A8 8 0 0 0 16 8M.152 9.56q.104.52.27 1.012l.948-.321a7 7 0 0 1-.237-.884l-.98.194zm15.425 1.012q.168-.493.27-1.011l-.98-.194q-.09.453-.237.884zM.824 11.54a8 8 0 0 0 .524.905l.83-.556a7 7 0 0 1-.458-.793zm13.828.905q.292-.434.524-.906l-.896-.443q-.205.413-.459.793zm-12.667.83q.346.394.74.74l.66-.752a7 7 0 0 1-.648-.648zm11.29.74q.394-.346.74-.74l-.752-.66q-.302.346-.648.648zm-1.735 1.161q.471-.233.905-.524l-.556-.83a7 7 0 0 1-.793.458zm-7.985-.524q.434.292.906.524l.443-.896a7 7 0 0 1-.793-.459zm1.873.925q.493.168 1.011.27l.194-.98a7 7 0 0 1-.884-.237zm4.132.271a8 8 0 0 0 1.012-.27l-.321-.948a7 7 0 0 1-.884.237l.194.98zm-2.083.135a8 8 0 0 0 1.046 0l-.064-.998a7 7 0 0 1-.918 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3z"/>
            </svg> ADD PRODUCT
            </Link>
          </div>
        <Table>
        <thead>
          <tr className="bg-primary text-white">
            <th>#</th>
            <th>Name</th>
            <th>Discription</th>
            <th>FinalPrice</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {productsList.map((data) => 
            <tr className="border-bottom">
              <td>{data._id.substr('19').padStart('9', '*')}</td>
              <td>{data.productName}</td>
              <td>{data.productDiscription}</td>
              <td>{data.productFinalPrice}</td>
              <td className="d-flex align-items-center justify-content-center border-0" style={{gap:'10px'}}> 
                <abbr title="pre-view">
                  <Link to={'/pre-view-product?id=' + data._id}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                    <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                    <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                  </svg>
                  </Link>
                </abbr>
                <abbr title="Edit">
                  <Link to={'/editproduct?id=' + data._id}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/></svg>
                  </Link>
                </abbr> 
                <abbr title="Delete">
                  <Link to='/products'>
                    <svg xmlns="http://www.w3.org/2000/svg" onClick={() => delectProduct(data._id, data.productName)} style={{cursor:'pointer'}} width="23  " height="23  " fill="currentColor" class="text-danger bi bi-trash3-fill" viewBox="0 0 16 16"><path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06m6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528M8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5"/></svg>
                  </Link>
                </abbr> 
              </td>
            </tr>
          )}
          
        </tbody>
      </Table>
      </div>
    );
}

export default Product;