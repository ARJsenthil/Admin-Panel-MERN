import '../../assets/style/product/product.css';
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Breadcrumb, Spinner, Table } from "react-bootstrap";
import { ActionGetProductListById } from "../actions/products";
import { Link, useNavigate } from "react-router-dom";


function Product()
{

  const dispatch = useDispatch();
  const [productName, setProductName] = useState('');
  const [productDiscription, setProductDiscription] = useState('');
  const [productImg, setProductImg] = useState([]);
  const [productOrginalPrice, setProductOrginalPrice] = useState();
  const [productDiscountType, setProductDiscountType] = useState('-1');
  const [productDiscount, setProductDiscount] = useState('0');
  const [productFinalPrice, setProductFinalPrice] = useState();
  const [productQuantityLimit, setProductQuantityLimit] = useState();
  const [productType, setProductType] = useState('');
  const [maxMinQua, setMaxMinQua] = useState(1);
  
  const [productDiscountManditary, setProductDiscountManditary] = useState(false);
  const [loading, setLoading] = useState(true);

  const numberRegex = /^\d*$/;

  const searchParams = new URLSearchParams(window.location.search);
  const id = searchParams.get('id');
  
  useEffect(() => {
    setLoading(true)
    onload(id);
  }, [id])
  const onload = async (id) => {
    try{
    await dispatch(ActionGetProductListById(id))
    }
    catch(e){

    }
    finally{
      setLoading(false)
    }

  }

  const product = useSelector((state) => state)
  const productList = product.productsReducer.productListById;
  console.log(productList)

  useEffect(() => {
    console.log('123')
    setProductName(productList.productName)
    setProductDiscription(productList.productDiscription)
    setProductImg(productList.productImg)
    setProductOrginalPrice(parseInt(productList.productOrginalPrice))
    setProductDiscountType(productList.productDiscountType)
    setProductDiscount(parseInt(productList.productDiscount))
    if(productList.productDiscountType == '-1')
    {
      setProductDiscountManditary(false)
    }
    else
    {
      setProductDiscountManditary(true)
    }
  
    setProductFinalPrice(parseInt(productList.productFinalPrice))
    setProductQuantityLimit(parseInt(productList.productQuantityLimit))
    setProductType(productList.productType)
    cl();
  }, [productList])
  const nav = useNavigate();

  const cl = () =>
    {
        

      const product_price = document.getElementById('product_price');
      const product_org_price = document.getElementById('product_org_price');
      const product_discount = document.getElementById('product_discount');
      const product_dis_type = document.getElementById('product_dis_type');
      var max_min_value = document.getElementById('max_min');
    
        // localStorage.setItem('maxQua', max_min_value.value);
        var a = maxMinQua;
        console.log(productList.productFinalPrice)
        setProductFinalPrice('₹'+productList.productFinalPrice);
        if(productList.productDiscountType == '%')
        {
          setProductDiscount(productList.productDiscount);
          setProductDiscountType(productList.productDiscountType+'off');
        }
        else if(productList.productDiscountType == 'flat')
        {
          setProductDiscount('₹'+productList.productDiscount);
          setProductDiscountType('off');
        }
        else if(productList.productDiscountType == '-1')
        {
          setProductOrginalPrice('');
          setProductDiscountType('');
          setProductDiscount('');
        }
        if(productList.productDiscountType == 'flat')
        {
          setProductDiscount('₹'+(productList.productDiscount * a));
        }
        
    }


    const  pluse = () =>
    {
        

        console.log(productQuantityLimit)
        if(maxMinQua < productQuantityLimit)
        {
            var max_min_value = maxMinQua;
            max_min_value++;
            setMaxMinQua(max_min_value);
            localStorage.setItem('maxQua', max_min_value);
            var a = max_min_value;
            var finalPrice = 1;
            setProductFinalPrice('₹'+(Math.round(parseInt(productList.productFinalPrice)) * a));
            if(productList.productDiscountType == '%' || productList.productDiscountType == 'flat')
            {
              console.log(Math.round(productList.productOrginalPrice) * a)
              setProductOrginalPrice('₹'+(Math.round(productList.productOrginalPrice) * a));
            }
            if(productList.productDiscountType == 'flat')
            {
              setProductDiscount('₹'+(productList.productDiscount * a));
            }
        }


    }


    const  minus = () =>
    {
        

        console.log(productQuantityLimit)
        if(maxMinQua !== 1) {
        if(maxMinQua < productQuantityLimit)
        {
            var max_min_value = maxMinQua;
            max_min_value--;
            setMaxMinQua(max_min_value);
            console.log(max_min_value)


            localStorage.setItem('maxQua', max_min_value);
            var a = max_min_value;
            setProductFinalPrice('₹'+(Math.round(productList.productFinalPrice) * a));
            if(productList.productDiscountType == '%' || productList.productDiscountType == 'flat')
            {
              setProductOrginalPrice('₹'+(Math.round(productList.productFinalPrice) * a));
            }
            if(productList.productDiscountType == 'flat')
            {
              setProductDiscount('₹'+(productList.productDiscount * a));
            }
        }
      }


    }
    if(loading)
      {
        return <Spinner animation="border" className="position-absolute" style={{ top : '50%', left : '50%', transform : 'translate(-50%. -50%)' }} variant="primary" />
      }

    return(
        <div class="container">
        <Breadcrumb>
                <Breadcrumb.Item><Link to="/">Home</Link></Breadcrumb.Item>
                <Breadcrumb.Item><Link to="/products">Products</Link></Breadcrumb.Item>
                <Breadcrumb.Item><Link to={`/pre-view-product?id=${id}`}>PreViewProduct</Link></Breadcrumb.Item>
        </Breadcrumb>
            <div class="row">
                <div class="col-md-5 col-sm-12 bg-dark text-white img_cont" style={{height: '500px'}}>
                
                    <h5 class="py-2" style={{height : '40px'}}>Product Image</h5>
                    <img src={`data:image/jpeg;base64,${productImg}`} alt="" className="img" id="img" class="w-100 pb-3" style={{height : '450px'}} />
                        
                </div>
                <div class="col-md-7 col-sm-12 position-relative" style={{height: '500px', backgroundColor: 'rgba(59, 216, 80, 0.79)'}}>
                
                    <h1 className="product_name" id="product_name">{productName}</h1>
                    <h3 class="d-flex" className="product_price_parent"><span className="product_price" id="product_price">{productFinalPrice}</span> <del className="product_org_price" id="product_org_price">{productOrginalPrice}</del> <span style={{color: 'green'}}><span className="product_discount" id="product_discount">{productDiscount}</span><span className="product_dis_type" id="product_dis_type">{productDiscountType}</span></span> </h3>
                    <p className="product_des" id="product_des">{productDiscription}</p>
                    <div className='btn-parent w-100'>
                      <div class="max-min"><button onClick={minus} class="minus">-</button><input type="text" name="" className="max_min" id="max_min" value={maxMinQua} style={{maxWidth : '30px !important'}} readonly /><button onClick={pluse} class="pluse">+</button></div>
                      <Link to={`/addToCart?id=${id}`} class="addToCart " >Add To Cart</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Product;