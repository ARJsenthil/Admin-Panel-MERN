import { useDispatch, useSelector } from 'react-redux';
import '../../assets/style/product/addToCart.css';
import { useEffect, useState } from "react";
import { ActionGetProductListById } from '../actions/products';
import { Breadcrumb } from 'react-bootstrap';
import { Link } from 'react-router-dom';


function AddToCart()
{

  const dispatch = useDispatch();
  const [productName, setProductName] = useState('');
  const [productDiscription, setProductDiscription] = useState('');
  const [productImg, setProductImg] = useState([]);
  const [productOrginalPrice, setsetProductOrginalPrice] = useState();
  const [productDiscountType, setProductDiscountType] = useState('-1');
  const [productDiscount, setProductDiscount] = useState('0');
  const [productFinalPrice, setProductFinalPrice] = useState();
  const [productQuantityLimit, setProductQuantityLimit] = useState();
  const [productType, setProductType] = useState('');
  const [quantity, setQuantity] = useState(localStorage.getItem('maxQua'));
  
  const [productDiscountManditary, setProductDiscountManditary] = useState(false);

  const numberRegex = /^\d*$/;

  const searchParams = new URLSearchParams(window.location.search);
  const id = searchParams.get('id');
  
  useEffect(() => {
    onload(id);
  }, [id])
  const onload = (id) => {
    dispatch(ActionGetProductListById(id))

  }

  const product = useSelector((state) => state)
  const productList = product.productsReducer.productListById;
  console.log(productList)

  useEffect(() => {
    console.log('123')
    setProductName(productList.productName)
    setProductDiscription(productList.productDiscription)
    setProductImg(productList.productImg)
    setsetProductOrginalPrice(parseInt(productList.productOrginalPrice))
    setProductDiscountType(productList.productDiscountType)
    setProductDiscount(parseInt(productList.productDiscount))
    if(productList.productDiscountType == '-1')
    {
      setProductDiscountManditary(false)
    }
    else
    {
      setProductDiscountManditary(true)
    }
  
    setProductFinalPrice(parseInt(productList.productFinalPrice))
    setProductQuantityLimit(parseInt(productList.productQuantityLimit))
    setProductType(productList.productType)
    cl();
  }, [productList])
    
    const cl = () => {
    var product_price = document.getElementById('product_price');
    var product_price1 = document.getElementById('product_price1');
    var product_org_price = document.getElementById('product_org_price');
    var product_org_price1 = document.getElementById('product_org_price1');
    var product_discount = document.getElementById('product_discount');
    var product_dis_type = document.getElementById('product_dis_type');
    // var item_count = document.getElementById('item_count');
    var del_cost = document.getElementById('del_cost');
    var free = document.getElementById('free');

    var price = productList.productFinalPrice;
    var org_price = productList.productOrginalPrice;
    var discount = productList.productDiscount;
    var disType = productList.productDiscountType;
    var maxQua = localStorage.getItem('maxQua');


    product_price.innerHTML = '₹'+ maxQua * price;
    if(disType == '%')
    {
      product_discount.innerHTML = discount;
      product_dis_type.innerHTML = disType + 'off';
      product_org_price.innerHTML = '₹' + maxQua * org_price;
      product_org_price1.innerHTML = '₹' + maxQua * org_price;
    }
    else if(disType == 'flat')
    {
      console.log('123213')
      product_discount.innerHTML = '₹' + discount * maxQua;
      product_dis_type.innerHTML = 'off';
      product_org_price.innerHTML = '₹' + maxQua * org_price;
      product_org_price1.innerHTML = '₹' + maxQua * org_price;
    }

    var c = org_price - price;
    var pro_dis = document.getElementById('pro_dis');
    
    if(org_price > 499)
    {
    del_cost.innerHTML = '₹' + maxQua * 40;
    del_cost.style = 'text-decoration: line-through;'
    
    if(disType != '-1')
    {
      product_price1.innerHTML = '₹' + maxQua * price;
      product_org_price1.innerHTML = '₹' + maxQua * org_price;
      pro_dis.innerHTML = '-₹' + maxQua * c;
    }
    else
    {
      product_price1.innerHTML = '₹' + maxQua * price;
      product_org_price1.innerHTML = '₹' + maxQua * price;
      pro_dis.innerHTML = 'No Discount';
      pro_dis.style = 'color: inherit;'
    }
    }
    else
    {
    del_cost.innerHTML = '₹' + maxQua * 40;
    free.style = 'display: none;';

    if(disType != '-1')
    {
      product_price1.innerHTML = '₹' + (( maxQua * price ) + ( maxQua * 40 ));
      product_org_price1.innerHTML = '₹' + maxQua * org_price;
      pro_dis.innerHTML = '-₹' + maxQua * c;
    }
    else
    {
      product_price1.innerHTML = '₹' + (( maxQua * price ) + ( maxQua * 40 ));
      product_org_price1.innerHTML = '₹' + maxQua * price;
      pro_dis.innerHTML = 'No Discount';
      pro_dis.style = 'color: inherit;'
    }
    }
    
    }
    return(
        <div class="p-5 container">
        <Breadcrumb>
                <Breadcrumb.Item><Link to="/">Home</Link></Breadcrumb.Item>
                <Breadcrumb.Item><Link to="/products">Products</Link></Breadcrumb.Item>
                <Breadcrumb.Item><Link to={`/pre-view-product?id=${id}`}>PreViewProduct</Link></Breadcrumb.Item>
                <Breadcrumb.Item><Link to={`/addToCart?id=${id}`}>AddToCart</Link></Breadcrumb.Item>
        </Breadcrumb>
            <div class="row m-auto">
                <img  src={`data:image/jpeg;base64,${productImg}`} alt="" className="col-lg-3 col-md-6 col-sm-5 img" id="img"/>
                <div class="col-lg-6 col-md-6 col-sm-7 p-lg-3 p-1 product-details" style={{backgroundColor: "rgba(0, 128, 0, 0.445)"}}>

                    <h1 className="product_name" id="product_name">{productName}</h1>
                    <p className="product_des" id="product_des">{productDiscription}</p>
                    <h3 className="d-flex product_price_parent" id="product_price_parent"><span className="product_price" id="product_price"></span><del className="product_org_price" id="product_org_price"></del><span style={{color: "green"}}><span className="product_discount" id="product_discount"></span><span className="product_dis_type" id="product_dis_type"></span></span> </h3>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 d-grid price-detais" style={{gap: "10px"}}>
                    <h6 class="pt-3 pb-3">PRICE DETAILS</h6>
                    <p class="row"><span class="col-7">Price Item({quantity})</span><span class="" className="col-5 product_org_price1" id="product_org_price1"></span></p>
                    <p class="row"><span class="col-7">Discount</span><span class="" className="pro_dis col-5 text-success" id="pro_dis"></span></p>
                    <p class="row"><span class="col-7" >Deleviry Cost</span><span  class="col-5 text-success" id=""><span className="del_cost" id="del_cost" style={{color: "rgba(0, 0, 0, 0.79)"}}></span> <span className="free" id="free">Free</span></span></p>
                    <p class="row"><span class="col-7">Total Cost</span><span class="" className="col-5 product_price1" id="product_price1"></span></p>
                </div>
            </div>
        </div>
    );
}

export default AddToCart;