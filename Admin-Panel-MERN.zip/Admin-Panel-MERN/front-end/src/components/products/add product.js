import axios from "axios";
import { useState } from "react";
import { Breadcrumb, Button, Form } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import swal from "sweetalert";

function AddProduct() {

      const nav = useNavigate();
  
  const [productName, setProductName] = useState('');
  const [productDiscription, setProductDiscription] = useState('');
  const [productImg, setProductImg] = useState([]);
  const [productOrginalPrice, setsetProductOrginalPrice] = useState('');
  const [productDiscountType, setProductDiscountType] = useState('-1');
  const [productDiscount, setProductDiscount] = useState('0');
  const [productFinalPrice, setProductFinalPrice] = useState('');
  const [productQuantityLimit, setProductQuantityLimit] = useState('');
  const [productType, setProductType] = useState('');
  
  const [productDiscountManditary, setProductDiscountManditary] = useState(false);


  const numberRegex = /^\d*$/;

  const product_Discount_Type = document.getElementById('product_Discount_Type');
  const product_Orginal_Price = document.getElementById('product_Orginal_Price');
  const product_Discount = document.getElementById('product_Discount');
  const product_Final_Price = document.getElementById('product_Final_Price');
  const productOrgPrice = () =>
    {
      const product_Discount_Type = document.getElementById('product_Discount_Type');
      const product_Orginal_Price = document.getElementById('product_Orginal_Price');
      const product_Discount = document.getElementById('product_Discount');
      const product_Final_Price = document.getElementById('product_Final_Price');
      if(product_Discount.value.length > 0)
      {
      if(product_Discount_Type.value == '%')
      {
        setProductDiscountManditary(true)
          if(product_Discount.value)
          {
              var d = parseInt(product_Orginal_Price.value) - (parseInt(product_Orginal_Price.value) * (parseInt(product_Discount.value)/100));
              console.log('%', d);
              setProductFinalPrice(Math.round(d));
          }
      }
      else if(product_Discount_Type.value == 'flat')
      {
        setProductDiscountManditary(true)
  
          if(product_Discount.value)
          {
              var d = parseInt(product_Orginal_Price.value) - parseInt(product_Discount.value);
              console.log('Flat', d);
              setProductFinalPrice(Math.round(d));
          }
      }
      else
      {
        setProductFinalPrice(product_Orginal_Price.value);
          setProductDiscount('0')
      }
    }
    else
    {
      setProductFinalPrice(product_Orginal_Price.value);
    }
    }
    const disTypeSelect = () =>
    {
      const product_Discount_Type = document.getElementById('product_Discount_Type');
      const product_Orginal_Price = document.getElementById('product_Orginal_Price');
      const product_Discount = document.getElementById('product_Discount');
      const product_Final_Price = document.getElementById('product_Final_Price');
      if(product_Discount_Type.value == '%')
      {
          product_Discount.value = '';
          setProductDiscount('')
          setProductDiscountManditary(true)
          if(product_Discount.value)
          {
              var d = parseInt(product_Orginal_Price.value) - (parseInt(product_Orginal_Price.value) * (parseInt(product_Discount.value)/100));
              console.log('%', d);
              setProductFinalPrice(Math.round(d));
          }
          else
          {
              var d = product_Orginal_Price.value;
  
          if(d != '')
          {
            setProductFinalPrice(Math.round(d));
          }
          else
          {
            setProductFinalPrice('');
          }
          }
      }
      else if(product_Discount_Type.value == 'flat')
      {
          product_Discount.value = '';
          setProductDiscount('')
          setProductDiscountManditary(true)
          if(product_Discount.value)
          {
              var d = parseInt(product_Orginal_Price.value) - parseInt(product_Discount.value);
              console.log('Flat', d);
              setProductFinalPrice(Math.round(d));
          }
          else
          {
              var d = product_Orginal_Price.value;
  
          if(d != '')
          {
            setProductFinalPrice(Math.round(d));
          }
          else
          {
            setProductFinalPrice('');
          }
          }
      }
      else if(product_Discount_Type.value == '-1')
      {
        setProductDiscountManditary(false)
  
          var d = parseInt(product_Orginal_Price.value);
          setProductDiscount('0')
  
          if(d)
          {
            setProductFinalPrice(Math.round(d));
          }
          else
          {
            setProductFinalPrice('');
          }
      }
    }
    const disPriceCount = () =>
    {
      const product_Discount_Type = document.getElementById('product_Discount_Type');
      const product_Orginal_Price = document.getElementById('product_Orginal_Price');
      const product_Discount = document.getElementById('product_Discount');
      const product_Final_Price = document.getElementById('product_Final_Price');
      setProductFinalPrice('');  
      if(product_Discount.value.length > 0)
      {
        if(product_Discount_Type.value == '%')
        {
            var d = parseInt(product_Orginal_Price.value) - (parseInt(product_Orginal_Price.value) * (parseInt(product_Discount.value)/100));
            if(d > 0)
            {
              setProductFinalPrice(Math.round(d));                  
            }
            else
            {
              // setProductFinalPrice('');
            }
        }
        else if(product_Discount_Type.value == 'flat')
        {
            var d = parseInt(product_Orginal_Price.value) - parseInt(product_Discount.value);
            if(d > 0)
            {
              setProductFinalPrice(Math.round(d));                  
            }
            else
            {
              setProductFinalPrice('');
            }
        }
        
      }
      else
      {
        setProductFinalPrice(productOrginalPrice)
      }
    }
  const inp = (event) =>
  {
    if(event.target.id == 'product_Name')
    {
      setProductName(event.target.value);
    }
    else if(event.target.id == 'product_Discription')
    {
      setProductDiscription(event.target.value);
    }
    else if(event.target.id == 'product_Orginal_Price')
    {
      if(numberRegex.test(event.target.value))
      {
        setsetProductOrginalPrice(event.target.value);
        productOrgPrice();
      }

    }
    else if(event.target.id == 'product_Discount_Type')
    {
        setProductDiscountType(event.target.value);
        disTypeSelect();
    }
    else if(event.target.id == 'product_Discount')
    {
      console.log('dis')
      if(numberRegex.test(event.target.value))
      {
        setProductDiscount(event.target.value);
        disPriceCount();
      }
    }
    else if(event.target.id == 'product_Final_Price')
    {
      setProductFinalPrice(event.target.value);
    }
    else if(event.target.id == 'product_Quantity_Limit')
    {
      if(numberRegex.test(event.target.value))
      {
        setProductQuantityLimit(event.target.value);
      }
    }
    else if(event.target.id == 'product_Type')
    {
      setProductType(event.target.value);
    }
    else if(event.target.id == 'product_Img')
    {
      setProductImg(event.target.files[0]);

      var fileReader = new FileReader();
      fileReader.onload = function(){
        var output = document.getElementById('productImg');
        output.src = fileReader.result;
    };
    fileReader.readAsDataURL(event.target.files[0]);
      // console.log(event.target.files[0].name = 'arj')
    }
  }
  const addUser = () =>
  {
    const productPhoto = new FormData();
    productPhoto.append('/productPhoto', productImg);

    let productData = {
      productName : productName,
      productDiscription : productDiscription,
      productOrginalPrice : productOrginalPrice,
      productDiscountType : productDiscountType,
      productDiscount : productDiscount,
      productFinalPrice : productFinalPrice,
      productQuantityLimit : productQuantityLimit,
      productType : productType
    }
    if(productName && productName && productOrginalPrice && productDiscountType && productDiscount && productFinalPrice && productQuantityLimit && productType && productImg) {
      axios.post('http://localhost:3001/products/addProduct', productPhoto, { params : productData, headers : {'Content-Type' : 'multipart/form-data'} } )
      .then(function (response) {
        console.log(response);
      nav('/products', { replace : true })
      swal('success', 'Product Added Successfully', 'success');
      })
      .catch(function (error) {
        swal('error', 'error', 'warning');
        // swal('error', 'error', 'warning');
        console.log(error);
      });
    }
    else
    {
      swal('Required', 'Fill the Required', 'warning');
    }
  }
  
  return (
    <div className="container">
    <Breadcrumb>
            <Breadcrumb.Item><Link to="/">Home</Link></Breadcrumb.Item>
            <Breadcrumb.Item><Link to="/products">Products</Link></Breadcrumb.Item>
            <Breadcrumb.Item><Link to="/addproduct">Add Products</Link></Breadcrumb.Item>
    </Breadcrumb>
    <Form className="d-grid" style={{gridTemplateColumns : 'auto auto'}}>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Name <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="Product Name" id="product_Name" onInput={inp} value={productName}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Discription <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="Product Discription" id="product_Discription" onInput={inp} value={productDiscription}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Orginal Price <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="Product Orginal Price" id="product_Orginal_Price" onInput={inp} value={productOrginalPrice}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label className="w-100">Product Discount Type <span className="text-danger">*</span></Form.Label>
        <select type="text" className="w-100 text-center" style={{height : '37.3px'}} id="product_Discount_Type" onInput={inp} value={productDiscountType}>
          <option value='-1'>No Discount</option>
          <option value='%'>Percentage %</option>
          <option value='flat'>Flat</option>
        </select>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Discount {productDiscountManditary?<span className="text-danger">*</span>:''}</Form.Label>
        <Form.Control type="text" placeholder="Product Discount" id="product_Discount" onInput={inp} {...(productDiscountManditary?{}:{disabled:true})} value={productDiscount}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Final Price <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="Product Final Price" id="product_Final_Price" onInput={inp} readOnly value={productFinalPrice}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Quantity Limit <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="Product Quantity Limit" id="product_Quantity_Limit" onInput={inp} value={productQuantityLimit}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label>Product Type <span className="text-danger">*</span></Form.Label>
        <Form.Control type="text" placeholder="What Type of Product" id="product_Type" onInput={inp} value={productType}/>
      </Form.Group>
      <Form.Group className="mb-3 px-1" controlId="formBasicEmail">
        <Form.Label for="file">Product Image <span className="text-danger">*</span></Form.Label>
        <Form.Control name="file" type="file" placeholder="product Image" id="product_Img" onInput={inp} />
      </Form.Group>
      
      <div className="d-inline-block px-1 m-auto pb-2">
        <img src="" title="Photo" alt="Photo" id="productImg" style={{height:"160px"}}/>
      </div>

    </Form>
      <Button variant="primary" className="w-100" type="button" onClick={addUser}>
        Submit
      </Button>
    </div>
  );
}

export default AddProduct;