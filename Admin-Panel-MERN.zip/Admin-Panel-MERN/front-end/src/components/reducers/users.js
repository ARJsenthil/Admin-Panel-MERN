
const initialState = {
    usersListDownload : [],
    usersList : [],
    userList : [],
    userListRes : []
}
const usersReducer = (state = initialState, action) => {
    console.log('usersreducer---',action)
    switch (action.type) {
        case 'GetUsersListDownload':
            return {...state, userList : action.payload};
        case 'GetUsersList':
            return {...state};
        case 'GetUserList':
            return {...state, userList : action.payload.message};
            return {...state, userListRes : action.payload};
        // case 'getUsersList':
        //     return {state};
        // case 'getVendorsList':
        //     return {state};
    
        default:
            return state;
    }
}
export default usersReducer;