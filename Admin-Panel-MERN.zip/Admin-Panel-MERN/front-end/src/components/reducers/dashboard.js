
const initialState = {
    productList : [],
    usersList : [],
    vendorsList : []
}
const dashboardReducer = (state = initialState, action) => {
    console.log('dashboardReducer-1-all',action)
    switch (action.type) {
        case 'GetProductList':
            return { ...state , productList : action.payload} ;
        case 'GetUsersList':
            return { ...state , usersList : action.payload} ;
        case 'GetVendorsList':
            return { ...state , productList : action.payload} ;
        default:
            return state;
    }
}
export default dashboardReducer;