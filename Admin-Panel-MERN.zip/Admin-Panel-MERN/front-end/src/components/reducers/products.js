
const initialState = {
    productList : [],
    productListById : [],
    loading : true
}
const productsReducer = (state = initialState, action) => {
    console.log('dashboardReducer-1-all',action)
    switch (action.type) {
        case 'GetProductListById':
            return { ...state , productListById : action.payload, loading : false} ;
        default:
            return state;
    }
}
export default productsReducer;