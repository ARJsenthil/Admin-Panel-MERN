
import { combineReducers } from "redux";
import dashboardReducer from "./reducers/dashboard";
import usersReducer from "./reducers/users";
import productsReducer from "./reducers/products";
const rootReducer = combineReducers({ dashboardReducer, usersReducer, productsReducer})

export default rootReducer;