import axios from "axios"

export function ActionGetProductListById(id)
{
    return function(dispatch)
    {
        return axios.post('http://localhost:3001/products/productListById', { id : id })
        .then((data) => {
            dispatch(GetProductListByIdFunction(data.data))
        })
    }

    function GetProductListByIdFunction(data)
    {
        console.log(data.data)
        return {
            type : 'GetProductListById',
            payload : data.data
        }
    }
}