import axios from "axios";

export function ActionGetProductList()
{
    return function(dispatch)
    {
        return axios.get('http://localhost:3001/products/productList')
        .then((data) => {
            dispatch(GetProductListFunction(data))
        })
    }

    function GetProductListFunction(data)
    {
        console.log(data.data)
        return {
            type : 'GetProductList',
            payload : data.data
        }
    }
}



export function ActionGetUsersList()
{
    return function(dispatch) {
        return axios.get("http://localhost:3001/users/userslist")
          .then(({ data }) => {
            dispatch(sendUsersDataList(data))
        });
    };

    function sendUsersDataList(data)
    {
        return {
            type : 'GetUsersList',
            payload : data
        };
    }
}

export function ActionGetVendorsList()
{
    return function(dispatch) {
        return axios.get("https://dummyjson.com/vendors")
          .then(({ data }) => {
            dispatch(sendUsersDataList(data))
        });
    };

    function sendUsersDataList(data)
    {
        return {
            type : 'GetVendorsList',
            payload : data
        };
    }
}