import axios from "axios";

export function ActionGetUsersList()
{
    return {
        type : 'GetUsersList',
        payload : ''
    };
}

export function ActionGetUserList(id)
{
    console.log('check')
    return function(dispatch) {
        return axios.post("http://localhost:3001/users/userlist", { id : id })
          .then(({ data }) => {
            dispatch(sendUserDataList(data))
        });
    };

    function sendUserDataList(data)
    {
        return {
            type : 'GetUserList',
            payload : data
        };
    }

}
