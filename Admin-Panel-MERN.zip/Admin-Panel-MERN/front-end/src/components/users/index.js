import axios from "axios";
import { useEffect, useState } from "react";
import { Breadcrumb, Spinner, Table } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import swal from "sweetalert";
import { ActionGetUsersList } from "../actions/dashboard";

function Users()
{
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);

    useEffect(() => {
      onLoad();
    }, []);
    const onLoad = async () =>
    {
      try{
        await dispatch(ActionGetUsersList());
      }
      catch(e){

      }
      finally{
        setLoading(false)
      }
    }
  const dashboardData = useSelector((state) => state);
  const usersList = dashboardData.dashboardReducer.usersList;

  const deleteUser = (id) =>
  {
    const data = [
      {
        id : id
      }
    ]
    axios.post('http://localhost:3001/users/deleteUser', {id : id})
    .then(function (response) {
      swal('Deleted', 'User Deleted Successfully', 'success');
      onLoad();
    })
    .catch(function (error) {
      swal('error', 'error', 'warning');
      console.log(error);
    });
  }

  const downloadPDF = async () => {
    const tableHtml = document.getElementById('table-id').outerHTML;
    const styles = '<style> body { text-align: center ; } #table-id { width: 100%;border: 1px solid black; border-collapse: collapse; } #table-id th, #table-id td { border: 1px solid black; padding: 8px; text-align: center;} .action{ display:none !important; }';

    try {
      const response = await axios.post('http://localhost:3001/users/generate-pdf', { tableHtml, styles}, {
        responseType: 'blob',
      });

      console.log(response)

      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'table.pdf');
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error('Error downloading PDF:', error);
    }
  }
  if(loading)
    {
      return <Spinner animation="border" className="position-absolute" style={{ top : '50%', left : '50%', transform : 'translate(-50%. -50%)' }} variant="primary" />
    }
    return(
        
        <div className="container">
          <div className="py-3 clearfix">
            <h3 className="d-inline-block" style={{float : "left"}}>User's List</h3>
            <Link to='/addusers' className="text-decoration-none" style={{float : "right"}}>
            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
            <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0m-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path d="M2 13c0 1 1 1 1 1h5.256A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1 1.544-3.393Q8.844 9.002 8 9c-5 0-6 3-6 4"/>
            </svg> ADD USERS
            </Link>
          </div>
        <Table id="table-id">
        <thead>
          <tr className="bg-primary text-white">
            <th>#ID</th>
            <th>Username</th>
            <th>Mail Id</th>
            <th>PH No..</th>
            <th className="action"></th>
          </tr>
        </thead>
        <tbody>
          {usersList.map((data) => 
            <tr className="border-bottom">
            <td>{data._id.substr('19').padStart('9', '*')}</td>
            <td>{data.firstname} {data.lastname}</td>
            <td>{data.mailId}</td>
            <td>{data.phoneNumber}</td>
            <td className="action d-flex align-items-center justify-content-center border-0" style={{gap:'10px'}}> <abbr title="Edit"><Link to={'/edituser?id=' + data._id}><svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
            </svg></Link></abbr> <abbr title="Delete"><Link to='/users'>
            <svg xmlns="http://www.w3.org/2000/svg" onClick={() => deleteUser(data._id)} style={{cursor:'pointer'}} width="23  " height="23  " fill="currentColor" class="text-danger bi bi-trash3-fill" viewBox="0 0 16 16">
            <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06m6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528M8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5"/>
            </svg>
            </Link></abbr> </td>
          </tr>
          )}
          
        </tbody>
      </Table>
      <button onClick={downloadPDF}>click</button>
 
      </div>
    );
}
export default Users;