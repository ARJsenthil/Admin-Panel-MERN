import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ActionGetProductList, ActionGetUsersList, ActionGetVendorsList } from '../actions/dashboard';
import dashboardReducer from '../reducers/dashboard';
import { Spinner } from 'react-bootstrap';
function DashBoard() {
    const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);
  useEffect(() => {
      onload();
    }, []);

  const onload = async () => {
    try{
    await dispatch(ActionGetProductList())
    await dispatch(ActionGetUsersList())
    }
    catch(e){

    }
    finally{
      setLoading(false)
    }

  }
    const dashboardData = useSelector((state) => state);
    const productList = dashboardData.dashboardReducer.productList;
    const usersList = dashboardData.dashboardReducer.usersList;
    console.log(dashboardData)
    
    console.log('hi ---',usersList);
    if(loading)
      {
        return <Spinner animation="border" className="position-absolute" style={{ top : '50%', left : '50%', transform : 'translate(-50%. -50%)' }} variant="primary" />
      }
  return (
    <Container>
      <Row>
        <Col className='p-5 bg-primary' style={{backgroundColor: ''}}>
          <Link className='text-decoration-none text-white d-flex' style={{gap : "10px", alignItems : "center"}} to='/products'>
            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-box-seam-fill" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M15.528 2.973a.75.75 0 0 1 .472.696v8.662a.75.75 0 0 1-.472.696l-7.25 2.9a.75.75 0 0 1-.557 0l-7.25-2.9A.75.75 0 0 1 0 12.331V3.669a.75.75 0 0 1 .471-.696L7.443.184l.01-.003.268-.108a.75.75 0 0 1 .558 0l.269.108.01.003zM10.404 2 4.25 4.461 1.846 3.5 1 3.839v.4l6.5 2.6v7.922l.5.2.5-.2V6.84l6.5-2.6v-.4l-.846-.339L8 5.961 5.596 5l6.154-2.461z"/>
            </svg> Products {productList.length}
          </Link>
        </Col>
        <Col className='p-5 bg-primary' style={{borderLeft: '1.5px solid white'}}>
          <Link className='text-decoration-none text-white d-flex' style={{gap : "10px", alignItems : "center"}} to='/users'>
            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
            <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
            </svg> Users {usersList.length}
          </Link>
        </Col>
        <Col className='p-5 bg-primary' style={{borderLeft: '1.5px solid white'}}>
        <Link className='text-decoration-none text-white d-flex' style={{gap : "10px", alignItems : "center"}} to='/new'>
          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
          <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.37 2.37 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0M1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5M4 15h3v-5H4zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1zm3 0h-2v3h2z"/>
          </svg>  Vendors
        </Link>
        </Col>
      </Row>
    </Container>
  );
}
export default DashBoard;