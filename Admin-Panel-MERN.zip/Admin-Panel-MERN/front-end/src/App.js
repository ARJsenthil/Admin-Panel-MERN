import TopBar from './components/layouts/topBar';
import LeftSideBar from './components/layouts/leftSlideBar';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import DashBoard from './components/dashboard';
import Users from './components/users';
import Product from './components/products';
import Vendors from './components/vendors';
import AddUsers from './components/users/add users';
import AddProduct from './components/products/add product';
import EditUser from './components/users/edit users';
import EditProduct from './components/products/edit product';
import PreViewProduct from './components/products/product';
import AddToCart from './components/products/addToCart';

function AdminApp() {
  return (
    <BrowserRouter>
      <div class="d-flex" id="wrapper">
        <LeftSideBar />
        <div id="page-content-wrapper">
          <TopBar />
          <div class="container-fluid">
            <Routes>
              <Route index path='/' element={<DashBoard />} />
              <Route path='/products' element={<Product />} />
              <Route path='/addproduct' element={<AddProduct />} />
              <Route path='/editproduct' element={<EditProduct />} />
              <Route path='/pre-view-product' element={<PreViewProduct />} />
              <Route path='/addToCart' element={<AddToCart />} />
              <Route path='/users' element={<Users />} />
              <Route path='/addusers' element={<AddUsers />} />
              <Route path='/edituser' element={<EditUser />} />
              <Route path='/new' element={<Vendors />} />
            </Routes>
          </div>
        </div>
      </div>
    </BrowserRouter>
    
  );
}

export default AdminApp;