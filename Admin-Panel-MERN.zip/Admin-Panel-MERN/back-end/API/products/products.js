const express = require('express')
const Productschema = require('../SCHEMA/productSchema/productschema')
const app = express()
const router = express.Router()
const mongoose = require('mongoose');
const multer = require('multer')
const jwt = require('jsonwebtoken')
mongoose.connect('mongodb://localhost:27017/arjun')

router.get('/productList', async (req, res) => {
  const productList = await Productschema.find({});
  console.log(productList);
  res.send(productList)
})

router.post('/productListById', async (req, res) => {
  const productListById = await Productschema.findOne({ _id : req.body.id });
  console.log(productListById);

  const fs = require('fs').promises
  
  try {
    const data = await fs.readFile(`./media/productPhotos/${productListById.productImg}`);
    const base64Image = Buffer.from(data).toString('base64');

    let productData = {
      productName : productListById.productName,
      productDiscription : productListById.productDiscription,
      productOrginalPrice : productListById.productOrginalPrice,
      productDiscountType : productListById.productDiscountType,
      productDiscount : productListById.productDiscount,
      productFinalPrice : productListById.productFinalPrice,
      productQuantityLimit : productListById.productQuantityLimit,
      productType : productListById.productType,
      productImg : base64Image
    }
    res.send({status  : 1, data : productData})
  } catch (err) {
    console.log(err);
  }
})

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'media/productPhotos')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      cb(null, 'img' + '-' + uniqueSuffix+'.'+'jpeg')
    }
  })
  
  const upload = multer({ storage: storage })
router.post('/addProduct',upload.single('/productPhoto'), async (req, res) => {
    const Product = new Productschema();
    Product.productName = req.query.productName;
    Product.productDiscription = req.query.productDiscription;
    Product.productOrginalPrice = req.query.productOrginalPrice;
    Product.productDiscountType = req.query.productDiscountType;
    Product.productDiscount = req.query.productDiscount;
    Product.productFinalPrice = req.query.productFinalPrice;
    Product.productQuantityLimit = req.query.productQuantityLimit;
    Product.productType = req.query.productType;
    Product.productImg = req.file.filename;
    const addProduct = await Product.save();
    res.send({ status : 1, message : 'success' })
})

router.post('/editproduct', upload.single('/productPhoto'), async (req, res) => {
  console.log(req.file)
  if(req.file == undefined)
  {
    
    let productData = {
      productName : req.query.productName,
      productDiscription : req.query.productDiscription,
      productOrginalPrice : req.query.productOrginalPrice,
      productDiscountType : req.query.productDiscountType,
      productDiscount : req.query.productDiscount,
      productFinalPrice : req.query.productFinalPrice,
      productQuantityLimit : req.query.productQuantityLimit,
      productType : req.query.productType
    }
    const editProduct = await Productschema.findOneAndUpdate({_id : req.query.id }, productData);
    // console.log('editProduct'+editProduct)
    res.send({ status : 1 })
    
  }
  else
  {
    
    let productData = {
      productName : req.query.productName,
      productDiscription : req.query.productDiscription,
      productOrginalPrice : req.query.productOrginalPrice,
      productDiscountType : req.query.productDiscountType,
      productDiscount : req.query.productDiscount,
      productFinalPrice : req.query.productFinalPrice,
      productQuantityLimit : req.query.productQuantityLimit,
      productType : req.query.productType,
      productImg : req.file.filename
    }
    const editProduct = await Productschema.findOneAndUpdate({_id : req.query.id }, productData);
    console.log(editProduct)
    console.log(req.file.filename)
    res.send({ status : 1 })

  }
})

router.post('/deleteProduct', async (req, res) => {
  // var token = req.headers.authorization;
  // if(!token) {
  //   res.status(400).send({ error : "Authorization token is missing" })
  // }
  // try {
    
  //   var decoded = jwt.verify(token, 'shhhhh');
  //   if(!req.body.id) {

  //     res.status(400).send({ error : "Product ID is Missing" })
  //   }
    const deleteProduct = await Productschema.deleteOne({ _id : req.body.id })
    if(deleteProduct.deletedCount == 0) {
      res.status(404).send({ error : "Product not found" })
    }
    res.send(deleteProduct)
  // } catch (err) {
    // res.status(401).send({ error : "Invalid Authorization Token" })
  // }
  console.log(req.body)
})
module.exports = router