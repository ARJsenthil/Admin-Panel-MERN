const puppeteer = require('puppeteer');
const express = require('express')
const UsersSchema = require('../SCHEMA/userSchema/userschema')
const app = express()
const router = express.Router()
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const fs = require('fs')
mongoose.connect('mongodb://localhost:27017/arjun')
const multer = require('multer');
router.get('/userslist', async (req, res) => {
    const usersList = await UsersSchema.find({});
    console.log(usersList);
    res.send(usersList)
})

router.post('/userlist', async (req, res) => {
    const userList = await UsersSchema.findOne({ _id : req.body.id });
    console.log(userList);
    const fs = require('fs').promises
  
    try {
      const data = await fs.readFile(`./media/profilePhotos/${userList.photo}`);
      const base64Image = Buffer.from(data).toString('base64');

    const userData =
    {
        firstname : userList.firstname,
        lastname : userList.lastname,
        phoneNumber : userList.phoneNumber,
        mailId : userList.mailId,
        photo : base64Image
    }
res.send({status  : 1, message : userData})
    } catch (err) {
      console.log(err);
    }
})
  
const storage = multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, 'media/profilePhotos')
        },
        filename: function (req, file, cb) {
          const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
          cb(null, 'img' + '-' + uniqueSuffix+'.'+'jpeg')
        }
      })
      
      const upload = multer({ storage: storage })

router.post('/addusers', upload.single('/photo'), async (req, res) => {
  const saltRounds = 5;
  console.log(req.file)
  console.log(req.params)
  const myPlaintextPassword = req.query.password;
  const d_pass = bcrypt.hashSync(myPlaintextPassword, saltRounds);
  const user = new UsersSchema();
  user.firstname = req.query.firstname
  user.lastname = req.query.lastname
  user.phoneNumber = req.query.phoneNumber
  user.mailId = req.query.mailId
  user.password = d_pass
  user.photo = req.file.filename
  console.log(req.file)
  const addUser = await user.save();
  console.log(addUser)
  res.send(addUser)
})

router.post('/edituser', upload.single('/photo'), async (req, res) => {
  console.log(req.file)
  if(req.file == undefined)
  {
    const userData =
    {
      firstname : req.query.firstname,
      lastname : req.query.lastname,
      phoneNumber : req.query.phoneNumber,
      mailId : req.query.mailId
    }
    const addUser = await UsersSchema.findOneAndUpdate({_id : req.query.id }, userData);
    console.log('adduser'+addUser)
    res.send({ status : 1 })
    
  }
  else
  {
    const userData =
    {
      firstname : req.query.firstname,
      lastname : req.query.lastname,
      phoneNumber : req.query.phoneNumber,
      mailId : req.query.mailId,
      photo : req.file.filename
    }
    const addUser = await UsersSchema.findOneAndUpdate({_id : req.query.id }, userData);
    console.log(addUser)
    console.log(req.file.filename)
    res.send({ status : 1 })

  }
})

router.post('/deleteUser', async (req, res) => 
{
  const deleteId = req.body.id
  const deleteOne = await UsersSchema.deleteOne({ _id : deleteId});
  res.send({status : 1, message : deleteOne})
})

router.post('/generate-pdf', async (req, res) => {
  try {
    const { tableHtml, styles } = req.body; // Get table HTML from request body

    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setContent(`<html>${styles}</style><body><h1>User's List</h1>${tableHtml}</body></html>`);
    const pdf = await page.pdf({ format: 'A4' });

    await browser.close();

    res.setHeader('Content-Type', 'application/pdf');
    res.send(pdf);
  } catch (error) {
    res.status(500).send('Error generating PDF');
  }
});

module.exports = router