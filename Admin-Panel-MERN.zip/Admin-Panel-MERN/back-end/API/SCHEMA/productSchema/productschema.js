const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    productName : String,
    productDiscription : String,
    productOrginalPrice : String,
    productDiscountType : String,
    productDiscount : String,
    productFinalPrice : String,
    productQuantityLimit : String,
    productType : String,
    productImg : String
})

module.exports = mongoose.model('productDetails', productSchema)