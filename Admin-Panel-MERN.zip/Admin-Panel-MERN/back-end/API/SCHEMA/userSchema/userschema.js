const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username : String,
    firstname : String,
    lastname : String,
    mailId : String,
    phoneNumber : Number,
    password : String,
    photo : String
})
module.exports = mongoose.model('users', userSchema);