const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const router = express.Router()
const products = require('./API/products/products')
const users = require('./API/users/users')
const cors = require('cors')
const port = 3001

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.get('/', (req, res) => {
  res.send('Hello World!')
})
app.use(cors())

app.use('/products', products)

app.use('/users', users)

app.get('/arr', (req, res) => {
    let arr = [
        {
            name : 'goku',
            power : 'ui'
        },
        {
            name : 'vegita',
            power : 'vegita blue'
        },
        {
            name : 'gohan',
            power : 'gohan power'
        }
    ]
    console.log(arr)
    res.send(arr[0].name)
    console.log(arr)
  })
  
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)

})
